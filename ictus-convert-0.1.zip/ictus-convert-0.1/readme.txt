ICTUS CONVERTER
Converts music notation files between MusicXML and MNX, in either direction,
and tells you what could not be carried across.

To see which version you have, run:   convert -version
It prints its own version and the MNX draft version it reads and writes.
Both matter: ours changes when we fix or add something, theirs changes when
the MNX format itself does, and a converted file can differ for either reason.
The version also heads the output of every conversion, so if you report a
problem, pasting that output says which build produced it.


WHAT YOU NEED

A Java virtual machine, version 8 or newer, and nothing else.

To find out whether you already have one, open a command prompt or terminal and
type

    java -version

with just one hyphen. If that prints a version number you are ready. If it says
the command is not found, install the latest OpenJDK - it is free, and each
system has its own easiest route, which is not the same route on all three; the
differences cost the author of this program an afternoon:

  LINUX
      A Java VM is often already part of your distribution. If it is not,
      install OpenJDK from your package manager or app store.

  macOS
      Use the Homebrew package manager, from https://brew.sh. Download it, run
      it, and follow its instructions for installing OpenJDK.

      Downloading a Java package directly is much harder than it looks - the
      installers and macOS itself are fussy about the combination of your chip
      (Intel or Apple silicon), your macOS version and the Java version, and a
      mismatch is not always reported clearly. Homebrew works out that
      combination for you.

  WINDOWS
      Microsoft publishes OpenJDK installers at

          https://learn.microsoft.com/en-us/java/openjdk/download

      Download the Windows one and run it. (That page carries builds for all
      three systems, if you would rather get them from one place.)

HOW TO USE IT

Put this folder anywhere you like. Open a command prompt in it and type the
name of a music file:

    convert  myscore.musicxml

and it writes two files beside it:

    ictus-myscore.mnx          the same music as MNX
    ictus-myscore-mnx.pdf      a picture OF THAT MNX FILE

The picture is drawn by reading back the file just written, not by drawing
what came in. So if the PDF looks right, the MNX file really is readable and
really does contain that music - which is the thing you wanted to know.

The PDF is named after the file it shows. Convert that MNX back again and you
get ictus-myscore.musicxml and ictus-myscore-xml.pdf beside it, so you can put
the two pictures side by side and see whether the music survived the round
trip.

Give it an MNX file instead and you get ictus-myscore.musicxml and
ictus-myscore-xml.pdf. There is nothing else to remember: it works out what
to do from the name of the file you gave it.

On Mac or Linux, type ./convert instead of convert - the leading ./ is
required, because those systems do not look in the current folder for
commands. If it answers "permission denied", the execute permission was lost
when the zip was unpacked (some graphical archive tools drop it); restore it
with:

    chmod +x convert

Or skip the launcher entirely - this always works, on every system:

    java -jar ictus-convert.jar  myscore.musicxml


YOUR OWN FILES ARE SAFE

Everything this program writes begins with "ictus-". It never writes over a
file of yours, and anything starting with "ictus-" can be deleted whenever you
like - run the converter again and you get it back.

If you run it twice, it replaces its own earlier output and says so.


IF YOU WANT SOMETHING DIFFERENT

    convert  myscore.musicxml  -nopdf
        convert only, skip the picture

    convert  myscore.mnx  wherever.musicxml
        name the output yourself; that name is used exactly as given

    convert  -version
        which version you have

If the convert command does not work on your system, this does the same thing:

    java -jar ictus-convert.jar  myscore.musicxml

Formats it knows:

    .xml  .musicxml           MusicXML, read and written
    .mxl                      MusicXML, compressed - read and written
    .mnx  .json               MNX, read and written
    .pdf                      written: a picture of the engraved music

A .mxl file is a MusicXML file inside a zip, and is what most notation programs
hand you by default. You never have to unpack one; give it to the converter as
it is. Name an output .mxl and you get one back, which for a large score is a
fraction of the size:

    convert  myscore.mnx  myscore.mxl


ABOUT THE PDF

Very little software can open an MNX file yet, so a converter that only writes
one is asking you to take the result on trust. The PDF is there so you can look
at what you got. It is the same page the program would send to a printer, at
300 dots per inch, one image per page.

It is a picture, not text: you cannot select or search the notes, and zooming
far in will show the pixels. It is meant for checking that the music survived,
not for publishing.


WHAT IT PRINTS, AND WHY THAT IS THE POINT

Converting between notation formats always loses something, because no two
formats describe music in quite the same way. Most converters lose it silently.
This one tells you, every time, in two lists:

  "the source said things we did not read"
      Something in your file that this program does not understand. If this
      list is long, treat the output with suspicion.

  "the score held things MNX cannot state"
      Something your file DID contain, which this program understood perfectly
      well, and which the target format has no way to express. This list is a
      description of the format, not of your file or of a bug.

For example, converting a song to MNX will usually report that the title, the
composer's name and all the page layout were lost. That is because MNX 1.0-draft
has nowhere to put them. Your music - the notes, rhythms, slurs, dynamics,
lyrics - comes through.


ONE LIMITATION WORTH KNOWING

The conversion works by reading your file into a full music database and then
writing that database out again in the other format. That is what makes the
reports above possible: the program can only tell you what was lost because it
holds a model of what was there.

The consequence is that anything the database does not model is lost even when
BOTH formats could have expressed it. So the reports tell you about the format's
limits, and the program's own limits show up as the first list.


IF SOMETHING GOES WRONG

The program exits with a message rather than a stack trace. A file it cannot
read at all usually means the file is not the format its name claims, or it is
compressed (.mxl is a zip; that is handled) or damaged.


ABOUT THIS PROGRAM

The converter is part of Ictus, a music notation editor in development. It is
the same importing and exporting code the editor itself uses, which is the
reason a converter this small can be this thorough - none of the conversion
logic is written twice.

It is offered as a working tool and as a reference implementation, particularly
for people working on the MNX format itself. There is no installer, no registry
entry and no background process: it is one jar file that reads a file and writes
a file.


LICENSING

Ictus is copyright 2006 Douglas M. Heyer and is licensed to you under the
Apache License, Version 2.0. In short: you may use it, for anything including
commercially, and you may pass it on or build on it, provided you keep the
copyright notice and say what you changed. It comes with no warranty. The full
text is apache-2.0.txt in the licenses folder, and the short version above is a
summary, not the licence itself.

This program also bundles two third-party works, both unmodified: the Gson
library (Apache License 2.0), and the Bravura music font (SIL Open Font
License 1.1, copyright Steinberg Media Technologies GmbH).

Bravura is included so that the program works on a machine with no music fonts
installed, which is the point of a download that asks you to install nothing
but Java.

@echo off
rem Ictus converter - see readme.txt
java -jar "%~dp0ictus-convert.jar" %*
